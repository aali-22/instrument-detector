import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from model import SimpleAudioCNN
from dataset import MelSpecDataset
import os
import csv


def train_one_epoch(model, loader, criterion, optimizer, device):
    """
    Run one training epoch over the provided DataLoader.
    Returns average loss and accuracy for the epoch.
    """
    model.train()
    running_loss, running_correct, total = 0.0, 0, 0
    for xb, yb in loader:
        xb, yb = xb.to(device), yb.to(device)
        optimizer.zero_grad()
        out = model(xb)
        loss = criterion(out, yb)
        loss.backward()
        optimizer.step()
        preds = out.argmax(dim=1)
        running_loss += loss.item() * xb.size(0)
        running_correct += (preds == yb).sum().item()
        total += xb.size(0)
    avg_loss = running_loss / total
    avg_acc = running_correct / total
    return avg_loss, avg_acc

def eval_one_epoch(model, loader, criterion, device):
    """
    Evaluate the model on the provided DataLoader.
    Returns average loss and accuracy for the epoch.
    """
    model.eval()
    running_loss, running_correct, total = 0.0, 0, 0
    with torch.no_grad():
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.to(device)
            out = model(xb)
            loss = criterion(out, yb)
            preds = out.argmax(dim=1)
            running_loss += loss.item() * xb.size(0)
            running_correct += (preds == yb).sum().item()
            total += xb.size(0)
    avg_loss = running_loss / total
    avg_acc = running_correct / total
    return avg_loss, avg_acc

def save_csv_log(log_path, log_rows):
    """
    Save training and validation metrics to a CSV file.
    """
    with open(log_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(["epoch", "train_loss", "train_acc", "val_loss", "val_acc"])
        writer.writerows(log_rows)

def main():
    # Print device info for user clarity
    print("CUDA available:", torch.cuda.is_available())
    if torch.cuda.is_available():
        print("GPU name:", torch.cuda.get_device_name(0))
    else:
        print("No GPU detected by PyTorch. Training will use CPU and may be slow.")

    # Training configuration
    train_mel_dir = "data/mel_spectrograms/train"
    train_json = "data/json/nsynth-train-filtered.json"
    val_mel_dir = "data/mel_spectrograms/valid"
    val_json = "data/json/nsynth-valid-filtered.json"
    batch_size = 32
    n_classes = 4
    n_mels = 128
    epochs = 50
    patience = 10
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    best_model_path = "outputs/best_model.pt"
    log_path = "outputs/train_log.csv"
    os.makedirs("outputs", exist_ok=True)

    # Prepare datasets and data loaders
    train_ds = MelSpecDataset(train_mel_dir, train_json)
    val_ds = MelSpecDataset(val_mel_dir, val_json, label_map=train_ds.label_map)
    train_dl = DataLoader(train_ds, batch_size=batch_size, shuffle=True, drop_last=True)
    val_dl = DataLoader(val_ds, batch_size=batch_size, shuffle=False)

    # Initialize model, loss, and optimizer
    model = SimpleAudioCNN(n_mels=n_mels, n_classes=n_classes).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=1e-3)

    best_val_acc = 0.0
    best_epoch = 0
    log_rows = []
    patience_counter = 0

    print("Starting training...")
    for epoch in range(1, epochs + 1):
        train_loss, train_acc = train_one_epoch(model, train_dl, criterion, optimizer, device)
        val_loss, val_acc = eval_one_epoch(model, val_dl, criterion, device)
        log_rows.append([epoch, train_loss, train_acc, val_loss, val_acc])
        print(f"Epoch {epoch:3d}: "
              f"Train Loss={train_loss:.4f} Acc={train_acc*100:.1f}% | "
              f"Val Loss={val_loss:.4f} Acc={val_acc*100:.1f}%")

        # Save model if validation accuracy improves
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            best_epoch = epoch
            torch.save(model.state_dict(), best_model_path)
            patience_counter = 0
            print(f"  New best model saved (val acc {val_acc*100:.1f}%)")
        else:
            patience_counter += 1
            if patience_counter >= patience:
                print(f"Early stopping at epoch {epoch} (no improvement for {patience} epochs)")
                break

    save_csv_log(log_path, log_rows)
    print(f"Training complete. Best val acc: {best_val_acc*100:.1f}% at epoch {best_epoch}")
    print(f"Best model saved to: {best_model_path}")
    print(f"Training log saved to: {log_path}")

if __name__ == "__main__":
    main()
